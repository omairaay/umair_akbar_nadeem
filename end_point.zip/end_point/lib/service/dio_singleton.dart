
import 'package:dio/dio.dart';
import 'package:get/get.dart';

import 'api.dart';

class DioSingleton {
  static final DioSingleton _dioSingleton = DioSingleton._internal();

  factory DioSingleton() {
    return _dioSingleton;
  }

  DioSingleton._internal();

  static Dio? dio;

  Dio getDio() {
    if (dio == null) {
      dio = Dio(BaseOptions(
          connectTimeout: 20000,
          receiveTimeout: 20000,
          baseUrl: "https://jsonplaceholder.typicode.com/"));
      dio!
        ..interceptors.add(InterceptorsWrapper(onRequest: (options, handler) {
          requestInterceptor(options);
          print("${options.uri}");
          return handler.next(options);
        }, onResponse: (response, handler) {
          // print(response.runtimeType);
          return handler.next(response);
        }, onError: (DioError e, handler) {
          if (e.response != null) {
            handleResponseErrors(e.response!.statusCode!);
          }
          return handler.next(e); //continue
        }));
    }
    return dio!;
  }

  dynamic requestInterceptor(RequestOptions options) {
    if (options.headers.containsKey("requiresToken")) {
      options.headers.remove("requiresToken");
      options.headers["authorization"] =
          // "Bearer " + GetStorage().read(userTokenKey)
          "Bearer Token"
      ;
      if (options.headers.containsKey("isMultiPart")) {
        //remove the auxiliary header
        options.headers.remove("isMultiPart");
        // options.headers.addAll({"Content-Type": "multipart/form-data"});
        options.headers["content-Type"] = "multipart/form-data";
      }
    }
    return options;
  }

  ApiHit apiHit(){
    return ApiHit();
  }


}
void handleResponseErrors(int statusCode) async {
  switch (statusCode) {
    case 400:
      Get.snackbar("Error", "User does not exist, please retry");
      break;
    case 401:
      Get.snackbar("Error", "Session expired, please login again");
      break;
    case 403:
      Get.snackbar("Error", "Access to this resource is forbidden");
      break;
    case 404:
      Get.snackbar("Error", "Resource not found, please retry");
      break;
    case 405:
      Get.snackbar("Error", "Method not allowed, please retry");
      break;
    case 408:
      Get.snackbar("Error", "An unexpected timeout occurred, please retry");
      break;
    case 409:
      Get.snackbar("Error", "A conflict occurred, please retry");
      break;
    case 415:
      Get.snackbar("Error", "Unsupported media type, please retry");
      break;
    case 500:
      Get.snackbar(
          "Error", "An internal error occured on the server, please retry");
      break;
    case 2000:
      Get.snackbar(
          "Timeout", "Unstable Internet");
      break;
    default:
      Get.snackbar("Error", "An unexpected error occurred");
      break;
  }

}