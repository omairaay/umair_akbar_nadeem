
import 'package:dio/dio.dart';
import 'dio_singleton.dart';

class ApiHit {

  Future<Response<dynamic>> getApi() {
    return DioSingleton().getDio().get(
      'posts/1/comments',
    );
  }

}