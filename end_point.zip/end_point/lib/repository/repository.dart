



import 'dart:convert';

import 'package:dio/dio.dart';


import '../model/model.dart';
import '../service/dio_singleton.dart';

class Repository{

  Future<List<Model>?> getApiHit() async {
    try {
      final Response =
      await DioSingleton().apiHit().getApi();
      if (Response.statusCode! >= 200 &&
          Response.statusCode! < 500) {
        List<Model> res = [];
        (jsonDecode(json.encode(Response.data))).forEach((element) {
          res.add(Model.fromJson(element));
        });
        return res;
      }
    } catch (e) {
      if (e is DioError) {
        print(e.message);
        return null;
      }
    }
  }
}