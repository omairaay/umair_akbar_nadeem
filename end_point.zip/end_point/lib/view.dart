
import 'package:get/get.dart';
import 'package:flutter/material.dart';

import 'controller/controller.dart';

class MyPage extends GetView<Controller> {
  const MyPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dummy'),
      ),
       body: SingleChildScrollView(
         child: Container(
           alignment: Alignment.center,
           child: Obx(() => controller.isLoading.value == false
           ? ListView.builder(
             shrinkWrap: true,
             physics: const PageScrollPhysics(),
             itemCount: controller.data.length == 0 ? 0 : controller.data.length ,
             itemBuilder: (context, index) {
               return ListTile(
                 leading: Text('Post ID ${controller.data[index].postId ?? ''}'),
                 trailing: Text('ID ${controller.data[index].id ?? ''}'),
                 title: Column(
                   mainAxisAlignment: MainAxisAlignment.center,
                   crossAxisAlignment: CrossAxisAlignment.center,
                   children: [
                     Text('Name ${controller.data[index].name ?? ''}'),
                     const SizedBox(height: 10,),
                     Text('Email ${controller.data[index].email ?? ''}'),
                   ],
                 ),
                 subtitle: Text('Body ${controller.data[index].body ?? ''}'),
               );
             },)
           : const CircularProgressIndicator()),
         ),
       ),
    );
  }

}

class MyPageBindings extends Bindings{
  @override
  void dependencies() {
    Get.lazyPut(() => Controller());
  }
}
