import 'package:get/get.dart';
import '../repository/repository.dart';

class Controller extends GetxController{
  Rx<bool> isLoading = false.obs;
  var data;
  Repository repo = Repository();

  fetchData()async {
    isLoading.value = true;
    data = await repo.getApiHit();
    print(data);
    isLoading.value = false;
  }

  @override
  void onInit() async {
    await fetchData();
    super.onInit();
  }
}