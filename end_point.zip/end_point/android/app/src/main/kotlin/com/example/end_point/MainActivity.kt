package com.example.end_point

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
